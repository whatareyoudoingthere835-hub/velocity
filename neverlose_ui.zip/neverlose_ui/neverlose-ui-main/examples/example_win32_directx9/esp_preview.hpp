#pragma once

#include "imgui.h"
#include "gui.hpp"

namespace esp_preview {
    inline bool show = true;
    inline void render() {
        if (!show) return;
        ImGui::SetNextWindowSize({350, 600}, ImGuiCond_FirstUseEver);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {0,0});
        ImGui::Begin("Interactive ESP Preview", &show, ImGuiWindowFlags_NoCollapse);
        ImVec2 size = ImGui::GetWindowSize();
        ImGui::PopStyleVar();

        // Placeholder image
        ImGui::SetCursorPos({(size.x - 200)/2.f, 50.f});
        ImGui::Dummy({200, 300});
        ImGui::GetWindowDrawList()->AddRectFilled(ImGui::GetItemRectMin(), ImGui::GetItemRectMax(), IM_COL32(50,50,50,255));
        ImGui::GetWindowDrawList()->AddText(ImGui::GetItemRectMin() + ImVec2(40,140), IM_COL32(255,255,255,255), "Player Model");

        ImGui::SetCursorPos({(size.x - 200)/2.f, size.y - 40.f});
        if (ImGui::Button(ICON_FA_COG " Manage Elements", {200, 30})) {
            ImGui::OpenPopup("Manage Elements Popup");
        }

        if (ImGui::BeginPopup("Manage Elements Popup")) {
            ImGui::Text("Manage Elements");
            ImGui::Separator();

            ImGui::Text("Main");
            static bool b1=true, b2=true, b3=true, b4=true, b5=false;
            gui.element_toggle("Box", &b1); ImGui::SameLine();
            gui.element_toggle("Name", &b2); ImGui::SameLine();
            gui.element_toggle("Health", &b3); ImGui::SameLine();
            gui.element_toggle("Health Bar", &b4); ImGui::SameLine();
            gui.element_toggle("Ammo Bar", &b5);
            
            ImGui::Text("Flags");
            static bool f1=true, f2=false, f3=true, f4=false, f5=true;
            gui.element_toggle("Armor", &f1); ImGui::SameLine();
            gui.element_toggle("Blind", &f2); ImGui::SameLine();
            gui.element_toggle("Zoom", &f3); ImGui::SameLine();
            gui.element_toggle("Reload", &f4); ImGui::SameLine();
            gui.element_toggle("Bomb", &f5);

            ImGui::EndPopup();
        }
        ImGui::End();
    }
}
