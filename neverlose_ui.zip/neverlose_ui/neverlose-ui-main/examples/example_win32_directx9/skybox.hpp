#pragma once

#include <windows.h>
#include <string>
#include <vector>
#include <fstream>
#include "sampapi/0.3.7-R3-1/sampapi.h"
#include "sampapi/0.3.7-R3-1/CGame.h"
#include "sampapi/0.3.7-R3-1/CObject.h"
#include "sampapi/0.3.7-R3-1/CPlayerPool.h"
#include "sampapi/0.3.7-R3-1/CNetGame.h"
#include "sampapi/0.3.7-R3-1/CEntity.h"

using namespace sampapi::v037r3;

typedef void* RwStream;
typedef void* RpClump;
typedef void* RwTexDictionary;

struct RwMemory {
    uint8_t* start;
    uint32_t length;
};
typedef RwStream (__cdecl *RwStreamOpen_t)(int type, int accessType, const void* pData);
static auto _RwStreamOpen = (RwStreamOpen_t)0x7EC810;

typedef int (__cdecl *RwStreamClose_t)(RwStream stream, void* pData);
static auto _RwStreamClose = (RwStreamClose_t)0x7EC9D0;

typedef int (__cdecl *RwStreamFindChunk_t)(RwStream stream, int type, int* lengthOut, int* versionOut);
static auto _RwStreamFindChunk = (RwStreamFindChunk_t)0x7ED2D0;

typedef RpClump (__cdecl *RpClumpStreamRead_t)(RwStream stream);
static auto _RpClumpStreamRead = (RpClumpStreamRead_t)0x74B030;

typedef RwTexDictionary (__cdecl *RwTexDictionaryStreamRead_t)(RwStream stream);
static auto _RwTexDictionaryStreamRead = (RwTexDictionaryStreamRead_t)0x732060;

typedef void (__cdecl *RwTexDictionarySetCurrent_t)(RwTexDictionary txd);
static auto _RwTexDictionarySetCurrent = (RwTexDictionarySetCurrent_t)0x732A00;

typedef RwTexDictionary (__cdecl *RwTexDictionaryGetCurrent_t)();
static auto _RwTexDictionaryGetCurrent = (RwTexDictionaryGetCurrent_t)0x7329A0;

typedef void (__cdecl *RpClumpDestroy_t)(RpClump clump);
static auto _RpClumpDestroy = (RpClumpDestroy_t)0x74A2B0;

typedef void (__cdecl *RwTexDictionaryDestroy_t)(RwTexDictionary txd);
static auto _RwTexDictionaryDestroy = (RwTexDictionaryDestroy_t)0x732520;

typedef void (__cdecl *CWorld_Remove_t)(void* entity);
static auto _CWorld_Remove = (CWorld_Remove_t)0x563280;

static sampapi::v037r3::CObject* g_SkyboxObject = nullptr;
static RpClump g_LoadedClump = nullptr;
static RwTexDictionary g_LoadedTxd = nullptr;

inline void DestroySkybox() {
    if (g_SkyboxObject) {
        void* pGameEnt = g_SkyboxObject->m_pGameEntity;
        if (pGameEnt) {
            _CWorld_Remove(pGameEnt);
            void** vtable = *(void***)pGameEnt;
            void (__thiscall* dtor)(void*, int) = (void(__thiscall*)(void*,int))vtable[0];
            dtor(pGameEnt, 1);
        }
        delete g_SkyboxObject;
        g_SkyboxObject = nullptr;
    }
    if (g_LoadedClump) {
        _RpClumpDestroy(g_LoadedClump);
        g_LoadedClump = nullptr;
    }
    if (g_LoadedTxd) {
        _RwTexDictionaryDestroy(g_LoadedTxd);
        g_LoadedTxd = nullptr;
    }
}

inline bool LoadSkybox(const std::string& dffPath, const std::string& txdPath) {
    DestroySkybox();

    std::ifstream txdFile(txdPath, std::ios::binary | std::ios::ate);
    if (!txdFile.is_open()) return false;
    std::streamsize txdSize = txdFile.tellg();
    txdFile.seekg(0, std::ios::beg);
    std::vector<uint8_t> txdData(txdSize);
    if (!txdFile.read((char*)txdData.data(), txdSize)) return false;

    RwMemory txdMem = { txdData.data(), (uint32_t)txdSize };
    RwStream txdStream = _RwStreamOpen(3, 1, &txdMem);
    if (!txdStream) return false;
    
    if (_RwStreamFindChunk(txdStream, 22, nullptr, nullptr)) {
        g_LoadedTxd = _RwTexDictionaryStreamRead(txdStream);
    }
    _RwStreamClose(txdStream, nullptr);
    if (!g_LoadedTxd) return false;

    RwTexDictionary oldTxd = _RwTexDictionaryGetCurrent();
    _RwTexDictionarySetCurrent(g_LoadedTxd);

    std::ifstream dffFile(dffPath, std::ios::binary | std::ios::ate);
    if (dffFile.is_open()) {
        std::streamsize dffSize = dffFile.tellg();
        dffFile.seekg(0, std::ios::beg);
        std::vector<uint8_t> dffData(dffSize);
        if (dffFile.read((char*)dffData.data(), dffSize)) {
            RwMemory dffMem = { dffData.data(), (uint32_t)dffSize };
            RwStream dffStream = _RwStreamOpen(3, 1, &dffMem);
            if (dffStream) {
                if (_RwStreamFindChunk(dffStream, 16, nullptr, nullptr)) {
                    g_LoadedClump = _RpClumpStreamRead(dffStream);
                }
                _RwStreamClose(dffStream, nullptr);
            }
        }
    }
    
    _RwTexDictionarySetCurrent(oldTxd);

    if (!g_LoadedClump) {
        DestroySkybox();
        return false;
    }

    DWORD minfo = *(DWORD*)(0xA9B0C8 + 4227 * 4);
    if (!minfo) return false;

    void* origClump = *(void**)(minfo + 0x1C);
    *(void**)(minfo + 0x1C) = g_LoadedClump;

    if (RefGame()) {
        CVector pos = {0.f, 0.f, 0.f};
        g_SkyboxObject = RefGame()->CreateObject(4227, pos, pos, 4000.f, 0, 0);
    }

    *(void**)(minfo + 0x1C) = origClump;

    if (g_SkyboxObject && g_SkyboxObject->m_pGameEntity) {
        void* pGameEnt = g_SkyboxObject->m_pGameEntity;
        *(BYTE*)((DWORD)pGameEnt + 0x1C) &= ~1;
    }

    return true;
}

inline void UpdateSkybox() {
    if (!g_SkyboxObject) return;
    if (!RefNetGame() || !RefNetGame()->GetPlayerPool()) return;
    
    CLocalPlayer* pLocal = RefNetGame()->GetPlayerPool()->GetLocalPlayer();
    if (pLocal && pLocal->m_pPed) {
        CMatrix matrix;
        pLocal->m_pPed->GetMatrix(&matrix);
        g_SkyboxObject->Teleport(matrix.pos);
    }
}
