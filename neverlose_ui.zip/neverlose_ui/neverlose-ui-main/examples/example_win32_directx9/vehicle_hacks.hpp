#pragma once
#include <windows.h>
#include <cmath>
#include "sampapi/0.3.7-R3-1/CNetGame.h"
#include "sampapi/0.3.7-R3-1/CPlayerPool.h"
#include "sampapi/0.3.7-R3-1/CLocalPlayer.h"
#include "sampapi/0.3.7-R3-1/CVehiclePool.h"

// ==================================================================================
//  Vehicle Hacks — ported from AmazingRP-DCPHACK-main
//  GTA SA memory offsets: 0xBA18FC = current vehicle ptr, 0xB6F178 = camera angle
// ==================================================================================

// Helper: patch bytes safely
static void VH_PatchBytes(void* address, const void* data, size_t size) {
    DWORD old;
    VirtualProtect(address, size, PAGE_EXECUTE_READWRITE, &old);
    memcpy(address, data, size);
    VirtualProtect(address, size, old, &old);
}

static void VH_PatchNOP(void* address, size_t size) {
    DWORD old;
    VirtualProtect(address, size, PAGE_EXECUTE_READWRITE, &old);
    memset(address, 0x90, size);
    VirtualProtect(address, size, old, &old);
}

// ---- Speedhack state ----
// GTA SA velocity unit: 1.0 unit/frame ≈ 180 km/h
// So target_speed_game = limit_kmh / 180.f
inline bool    g_speedhack_enabled   = false;
inline float   g_speedhack_kmh       = 80.0f;   // km/h limit shown to user
inline float   g_speedhack_sharpness = 0.15f;   // acceleration per frame [0.01..1.0]
inline int     g_speedhack_key       = VK_LMENU; // hold to activate

// ---- Car Jump state ----
inline bool    g_car_jump_enabled   = false;
inline float   g_car_jump_force     = 0.5f;
inline int     g_car_jump_key       = VK_LSHIFT;
static bool    s_jump_pressed       = false;

// ---- Nitro state ----
inline bool    g_nitro_enabled      = false;
static bool    s_last_nitro         = false;

// ---- Unlock Doors state ----
inline bool    g_unlock_doors_enabled = false;
static bool    s_last_doors           = false;

// ---- Faction Bypass — handled via RPC hook in main.cpp ----
inline bool    g_faction_bypass_enabled = false;

// ---- Unoccupied Bypass ----
inline bool    g_unoccupied_bypass_enabled = false;

// ---- Car Godmode ----
inline bool    g_car_godmode_enabled = false;
static bool    s_last_car_godmode    = false;

// ---- Always Asphalt ----
inline bool    g_always_asphalt_enabled = false;
static bool    s_last_always_asphalt    = false;

// ---- NoBike (NoFall) ----
inline bool    g_nobike_enabled = false;
static bool    s_last_nobike    = false;

// ==================================================================================
//  Call once per frame inside hkPresent (before ImGui render)
// ==================================================================================
inline void VehicleHacks_Tick() {
    DWORD pCurrentVehicle = *(DWORD*)0xBA18FC;

    // ---- Speedhack (HOLD mode) ----
    if (g_speedhack_enabled && pCurrentVehicle && pCurrentVehicle > 0x1000) {
        bool keyHeld = (g_speedhack_key != 0) && (GetAsyncKeyState(g_speedhack_key) & 0x8000);
        if (keyHeld) {
            if (!IsBadWritePtr((void*)(pCurrentVehicle + 0x44), 12)) {
                float* speedX = (float*)(pCurrentVehicle + 0x44);
                float* speedY = (float*)(pCurrentVehicle + 0x48);

                // Convert km/h limit to GTA SA game units
                // 1 game unit ≈ 180 km/h
                const float KMH_TO_GTA = 1.f / 180.f;
                float targetSpeedGTA = g_speedhack_kmh * KMH_TO_GTA;

                // Current horizontal speed
                float curSpeed = sqrtf((*speedX) * (*speedX) + (*speedY) * (*speedY));

                // Use vehicle matrix for forward direction
                float dirX = 0.f;
                float dirY = 0.f;
                DWORD pMatrix = *(DWORD*)(pCurrentVehicle + 0x14);
                if (pMatrix && !IsBadReadPtr((void*)pMatrix, 0x40)) {
                    // CMatrix up vector (forward in GTA SA) is at +0x10
                    dirX = *(float*)(pMatrix + 0x10);
                    dirY = *(float*)(pMatrix + 0x14);
                    // Normalize
                    float len = sqrtf(dirX * dirX + dirY * dirY);
                    if (len > 0.0001f) {
                        dirX /= len;
                        dirY /= len;
                    } else {
                        dirX = 0.f; dirY = 1.f;
                    }
                } else {
                    // Fallback to camera angle
                    float camAngle = *(float*)0xB6F178;
                    dirX = -sinf(camAngle);
                    dirY = cosf(camAngle);
                }

                // Lerp current speed toward target (smooth acceleration)
                float newSpeed = curSpeed + (targetSpeedGTA - curSpeed) * g_speedhack_sharpness;

                // Clamp so we never exceed the limit
                if (newSpeed > targetSpeedGTA) newSpeed = targetSpeedGTA;

                // Apply velocity in vehicle's forward direction
                *speedX = dirX * newSpeed;
                *speedY = dirY * newSpeed;
            }
        }
    }

    // ---- Car Jump ----
    if (g_car_jump_enabled && pCurrentVehicle && pCurrentVehicle > 0x1000) {
        bool keyHeld = (g_car_jump_key != 0) && (GetAsyncKeyState(g_car_jump_key) & 0x8000);
        if (keyHeld) {
            if (!s_jump_pressed && !IsBadWritePtr((void*)(pCurrentVehicle + 0x4C), 4)) {
                float* speedZ = (float*)(pCurrentVehicle + 0x4C);
                *speedZ += g_car_jump_force;
                s_jump_pressed = true;
            }
        } else {
            s_jump_pressed = false;
        }
    }

    // ---- Nitro toggle ----
    if (g_nitro_enabled != s_last_nitro) {
        DWORD oldProt;
        VirtualProtect((void*)0x969165, 1, PAGE_EXECUTE_READWRITE, &oldProt);
        *(BYTE*)0x969165 = g_nitro_enabled ? 1 : 0;
        VirtualProtect((void*)0x969165, 1, oldProt, &oldProt);
        s_last_nitro = g_nitro_enabled;
    }

    // ---- Unlock Doors toggle ----
    if (g_unlock_doors_enabled != s_last_doors) {
        static DWORD samp_dll = 0;
        if (!samp_dll) samp_dll = (DWORD)GetModuleHandleA("samp.dll");

        if (samp_dll) {
            if (g_unlock_doors_enabled) {
                VH_PatchBytes((void*)0x63E40F, "\xEB\xBA", 2);
                VH_PatchBytes((void*)(samp_dll + 0xA2FE8), "\x90\x90\x90\x90\x90\x90", 6);
                VH_PatchBytes((void*)(samp_dll + 0xA2FF2), "\x90\x90\x90\x90\x90\x90", 6);
                VH_PatchBytes((void*)(samp_dll + 0xA300A), "\x90\x90\x90\x90\x90\x90", 6);
                VH_PatchBytes((void*)(samp_dll + 0xA3021), "\x90\x90", 2);
                VH_PatchBytes((void*)(samp_dll + 0xA302C), "\x90\x90", 2);
                VH_PatchBytes((void*)(samp_dll + 0xA3035), "\xEB", 1);
                VH_PatchBytes((void*)(samp_dll + 0xA306F), "\xEB", 1);
            } else {
                VH_PatchBytes((void*)0x63E40F, "\x6A\x1C", 2);
                VH_PatchBytes((void*)(samp_dll + 0xA2FE8), "\x0F\x84\xAF\x00\x00\x00", 6);
                VH_PatchBytes((void*)(samp_dll + 0xA2FF2), "\x0F\x83\xA5\x00\x00\x00", 6);
                VH_PatchBytes((void*)(samp_dll + 0xA300A), "\x0F\x84\x8D\x00\x00\x00", 6);
                VH_PatchBytes((void*)(samp_dll + 0xA3021), "\x75\x7A", 2);
                VH_PatchBytes((void*)(samp_dll + 0xA302C), "\x74\x6F", 2);
                VH_PatchBytes((void*)(samp_dll + 0xA3035), "\x74", 1);
                VH_PatchBytes((void*)(samp_dll + 0xA306F), "\x74", 1);
            }
        }
        s_last_doors = g_unlock_doors_enabled;
    }

    // ---- Car Godmode ----
    if (g_car_godmode_enabled != s_last_car_godmode) {
        if (g_car_godmode_enabled) {
            VH_PatchBytes((void*)0x6A80E1, "\xE9\xC5\x02\x00\x00\x90", 6);
            VH_PatchBytes((void*)0x6B8EC0, "\xC2\x18\x00\x90\x90", 5);
            VH_PatchBytes((void*)0x6CC4B0, "\xC2\x18\x00", 3);
            VH_PatchBytes((void*)0x570DB6, "\xE9\x5E\x01\x00\x00\x90", 6);
            VH_PatchNOP((void*)0x6D8071, 7);
            VH_PatchBytes((void*)0x6D7CCE, "\xE9\xD6\x05\x00\x00\x90", 6);
        } else {
            VH_PatchBytes((void*)0x6A80E1, "\x0F\x85\xC4\x02\x00\x00", 6);
            VH_PatchBytes((void*)0x6B8EC0, "\x51\xD9\x44\x24\x08", 5);
            VH_PatchBytes((void*)0x6CC4B0, "\x83\xEC\x48", 3);
            VH_PatchBytes((void*)0x570DB6, "\x0F\x86\x5D\x01\x00\x00", 6);
            VH_PatchBytes((void*)0x6D8071, "\xD8\xA4\x24\x90\x00\x00\x00", 7);
            VH_PatchBytes((void*)0x6D7CCE, "\x0F\x84\xD5\x05\x00\x00", 6);
        }
        s_last_car_godmode = g_car_godmode_enabled;
    }

    // ---- Always Asphalt ----
    if (g_always_asphalt_enabled != s_last_always_asphalt) {
        if (g_always_asphalt_enabled) {
            VH_PatchNOP((void*)0x1563827, 3);
        } else {
            VH_PatchBytes((void*)0x1563827, "\x66\x8B\x3A", 3);
        }
        s_last_always_asphalt = g_always_asphalt_enabled;
    }

    // ---- NoBike (NoFall) ----
    if (g_nobike_enabled != s_last_nobike) {
        if (g_nobike_enabled) {
            VH_PatchBytes((void*)0x680B7A, "\xE9\xFB\xFE\xFF\xFF\x90", 6);
        } else {
            VH_PatchBytes((void*)0x680B7A, "\x0F\x84\xFA\xFE\xFF\xFF", 6);
        }
        s_last_nobike = g_nobike_enabled;
    }

    // ---- Unoccupied Bypass Sync ----
    if (g_unoccupied_bypass_enabled && pCurrentVehicle && pCurrentVehicle > 0x1000) {
        static DWORD lastSync = 0;
        DWORD now = GetTickCount();
        if (now - lastSync > 30) {
            DWORD pLocalPed = *(DWORD*)0xB6F5F0;
            if (pLocalPed && pLocalPed > 0x1000) {
                DWORD pDriver = *(DWORD*)(pCurrentVehicle + 0x460);
                if (pDriver != pLocalPed) {
                    // We are passenger! Check if we are using speedhack or jump (moving the car)
                    bool shHeld = g_speedhack_enabled && (g_speedhack_key != 0) && (GetAsyncKeyState(g_speedhack_key) & 0x8000);
                    bool jpHeld = g_car_jump_enabled && (g_car_jump_key != 0) && (GetAsyncKeyState(g_car_jump_key) & 0x8000);
                    if (shHeld || jpHeld) {
                        // We are moving the car from passenger seat, sync it!
                        if (sampapi::v037r3::RefNetGame()) {
                            auto vpool = sampapi::v037r3::RefNetGame()->GetVehiclePool();
                            auto ppool = sampapi::v037r3::RefNetGame()->GetPlayerPool();
                            if (vpool && ppool && ppool->GetLocalPlayer()) {
                                sampapi::ID vehId = vpool->Find((::CVehicle*)pCurrentVehicle);
                                if (vehId != 0xFFFF) {
                                    ppool->GetLocalPlayer()->SendUnoccupiedData(vehId, 0);
                                    lastSync = now;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================================================================================
//  Cleanup — call on DLL detach
// ==================================================================================
inline void VehicleHacks_Shutdown() {
    // Restore nitro
    DWORD oldProt;
    VirtualProtect((void*)0x969165, 1, PAGE_EXECUTE_READWRITE, &oldProt);
    *(BYTE*)0x969165 = 0;
    VirtualProtect((void*)0x969165, 1, oldProt, &oldProt);

    // Restore doors
    static DWORD samp_dll = 0;
    if (!samp_dll) samp_dll = (DWORD)GetModuleHandleA("samp.dll");
    if (samp_dll && g_unlock_doors_enabled) {
        VH_PatchBytes((void*)0x63E40F, "\x6A\x1C", 2);
        VH_PatchBytes((void*)(samp_dll + 0xA2FE8), "\x0F\x84\xAF\x00\x00\x00", 6);
        VH_PatchBytes((void*)(samp_dll + 0xA2FF2), "\x0F\x83\xA5\x00\x00\x00", 6);
        VH_PatchBytes((void*)(samp_dll + 0xA300A), "\x0F\x84\x8D\x00\x00\x00", 6);
        VH_PatchBytes((void*)(samp_dll + 0xA3021), "\x75\x7A", 2);
        VH_PatchBytes((void*)(samp_dll + 0xA302C), "\x74\x6F", 2);
        VH_PatchBytes((void*)(samp_dll + 0xA3035), "\x74", 1);
        VH_PatchBytes((void*)(samp_dll + 0xA306F), "\x74", 1);
    }
    
    // Restore Car Godmode
    if (g_car_godmode_enabled) {
        VH_PatchBytes((void*)0x6A80E1, "\x0F\x85\xC4\x02\x00\x00", 6);
        VH_PatchBytes((void*)0x6B8EC0, "\x51\xD9\x44\x24\x08", 5);
        VH_PatchBytes((void*)0x6CC4B0, "\x83\xEC\x48", 3);
        VH_PatchBytes((void*)0x570DB6, "\x0F\x86\x5D\x01\x00\x00", 6);
        VH_PatchBytes((void*)0x6D8071, "\xD8\xA4\x24\x90\x00\x00\x00", 7);
        VH_PatchBytes((void*)0x6D7CCE, "\x0F\x84\xD5\x05\x00\x00", 6);
    }

    // Restore Always Asphalt
    if (g_always_asphalt_enabled) {
        VH_PatchBytes((void*)0x1563827, "\x66\x8B\x3A", 3);
    }

    // Restore NoBike
    if (g_nobike_enabled) {
        VH_PatchBytes((void*)0x680B7A, "\x0F\x84\xFA\xFE\xFF\xFF", 6);
    }
}
