#pragma once
#include <string>
#include <vector>
#include <ctime>
#include <cmath>
#include "imgui.h"
#include "imgui_internal.h"
#include "gui.hpp"
#include "hashes.hpp"

#pragma warning(disable: 4996)

struct WatermarkData {
    std::string username = "Ultrabomj";
    int         fps      = 0;
    int         ping     = 0;
    float       tps      = 20.0f;
    float       bps      = 0.0f;
    int         coords[3]= { 0, 0, 0 };
};

class WatermarkComponent {
public:
    WatermarkData data;
    ImVec2 pos = { 10.f, 10.f };
    bool   dragging = false;
    ImVec2 drag_offset = { 0.f, 0.f };

    void render() {
        char timeStr[16];
        std::time_t t = std::time(nullptr);
        std::strftime(timeStr, sizeof(timeStr), "%H:%M:%S", std::localtime(&t));

        char fpsStr[32];   snprintf(fpsStr,  sizeof(fpsStr),  "%d Fps",     (int)ImGui::GetIO().Framerate);
        char pingStr[32];  snprintf(pingStr, sizeof(pingStr), "%d ms",      data.ping);
        char tpsStr[32];   snprintf(tpsStr,  sizeof(tpsStr),  "%.1f Ticks", data.tps);
        char bpsStr[32];   snprintf(bpsStr,  sizeof(bpsStr),  "%.1f Bps",   data.bps);
        char coordStr[64]; snprintf(coordStr,sizeof(coordStr),"%d %d %d",   data.coords[0], data.coords[1], data.coords[2]);

        ImFont* font  = ImGui::GetIO().Fonts->Fonts[0];
        const float fs = 15.f;
        const float PAD   = 8.f;
        const float H_ROW = 24.f;
        const float GAP   = 4.f;

        ImU32 accentCol   = gui.accent_color.to_im_color();
        ImU32 textCol     = IM_COL32(255, 255, 255, 255);
        ImU32 sepCol      = IM_COL32(128, 128, 128, 90);
        ImU32 bgCol       = IM_COL32(0, 0, 0, 160);
        ImU32 bgColBorder = IM_COL32(255, 255, 255, 12);

        ImDrawList* dl = ImGui::GetForegroundDrawList();
        float cx = pos.x;
        float cy = pos.y;
        float cx_start = cx;

        {
            float iW = 20.f;
            float w  = 4.f + iW + 4.f;

            dl->PushClipRect({cx, cy}, {cx + w, cy + H_ROW});
            draw_blur(dl);
            dl->PopClipRect();

            dl->AddRectFilled({cx, cy}, {cx + w, cy + H_ROW}, bgCol, 4.f);
            dl->AddRect      ({cx, cy}, {cx + w, cy + H_ROW}, bgColBorder, 4.f);

            float tx = cx + 4.f;
            float ty = cy + (H_ROW - 20.f) * 0.5f;

            if (g_watermark_tex) {
                dl->AddImage((ImTextureID)g_watermark_tex, {tx, ty}, {tx + 20.f, ty + 20.f}, {0,0}, {1,1}, IM_COL32(255, 255, 255, 255));
            }

            cx += w + GAP;
        }

        {
            const char* icons[3] = { ICON_FA_USER, ICON_FA_CHART_LINE, ICON_FA_CLOCK };
            const char* vals [3] = { data.username.c_str(), fpsStr, timeStr };

            float totalW = PAD;
            totalW += font->CalcTextSizeA(fs, FLT_MAX, 0, icons[0]).x + 4.f + font->CalcTextSizeA(fs, FLT_MAX, 0, data.username.c_str()).x + font->CalcTextSizeA(fs, FLT_MAX, 0, " | ").x;
            totalW += font->CalcTextSizeA(fs, FLT_MAX, 0, icons[1]).x + 4.f + font->CalcTextSizeA(fs, FLT_MAX, 0, "999 Fps").x + font->CalcTextSizeA(fs, FLT_MAX, 0, " | ").x;
            totalW += font->CalcTextSizeA(fs, FLT_MAX, 0, icons[2]).x + 4.f + font->CalcTextSizeA(fs, FLT_MAX, 0, "23:59:59").x;
            totalW += PAD;

            dl->PushClipRect({cx, cy}, {cx + totalW, cy + H_ROW});
            draw_blur(dl);
            dl->PopClipRect();

            dl->AddRectFilled({cx, cy}, {cx + totalW, cy + H_ROW}, bgCol, 4.f);
            dl->AddRect      ({cx, cy}, {cx + totalW, cy + H_ROW}, bgColBorder, 4.f);

            float tx = cx + PAD;
            float ty = cy + (H_ROW - fs) * 0.5f;

            for (int i = 0; i < 3; i++) {
                dl->AddText(font, fs, {tx, ty}, accentCol, icons[i]);
                tx += font->CalcTextSizeA(fs, FLT_MAX, 0, icons[i]).x + 4.f;
                dl->AddText(font, fs, {tx, ty}, textCol, vals[i]);
                
                if (i == 0) tx += font->CalcTextSizeA(fs, FLT_MAX, 0, data.username.c_str()).x;
                else if (i == 1) tx += font->CalcTextSizeA(fs, FLT_MAX, 0, "999 Fps").x;

                if (i < 2) {
                    dl->AddText(font, fs, {tx, ty - 1.f}, sepCol, " | ");
                    tx += font->CalcTextSizeA(fs, FLT_MAX, 0, " | ").x;
                }
            }
            cx += totalW + GAP;
        }

        float total_w = cx - cx_start;
        float total_h = H_ROW;

        ImVec2 mouse = ImGui::GetIO().MousePos;
        bool hovered = (mouse.x >= pos.x && mouse.x <= pos.x + total_w &&
                        mouse.y >= pos.y && mouse.y <= pos.y + total_h);

        if (hovered && ImGui::IsMouseClicked(0)) {
            dragging = true;
            drag_offset = { mouse.x - pos.x, mouse.y - pos.y };
        }
        if (!ImGui::IsMouseDown(0)) {
            dragging = false;
        }
        if (dragging) {
            pos.x = mouse.x - drag_offset.x;
            pos.y = mouse.y - drag_offset.y;
        }
    }
};
