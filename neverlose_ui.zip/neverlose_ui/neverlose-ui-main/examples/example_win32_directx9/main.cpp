#pragma warning(disable: 26495)
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <tchar.h>
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_dx9.h"
#include "imgui_impl_win32.h"
#include "minhook/include/MinHook.h"

#include "gui.hpp"
#include "hashes.hpp"
#include "blur.hpp"
#include "bytes.hpp"
#include "watermark.hpp"
#include "keybinds.hpp"
#include "esp.hpp"
#include "vehicle_hacks.hpp"
#include "skybox.hpp"
#include "icons_data.hpp"

using namespace sampapi;
using namespace sampapi::v037r3;
#include "sampapi/0.3.7-R3-1/CGame.h"

static bool bools[50]{};
static int ints[50]{};

WatermarkComponent g_watermark;
KeybindsComponent g_keybinds;

using namespace ImGui;

#define ALPHA    ( ImGuiColorEditFlags_AlphaPreview | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_InputRGB | ImGuiColorEditFlags_Float | ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_PickerHueBar | ImGuiColorEditFlags_NoBorder )
#define NO_ALPHA ( ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_InputRGB | ImGuiColorEditFlags_Float | ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_PickerHueBar | ImGuiColorEditFlags_NoBorder )

IDirect3DTexture9* avatar{ };
IDirect3DTexture9* g_watermark_tex{ };
IDirect3DTexture9* g_keybinds_tex{ };

typedef HRESULT(APIENTRY* Present_t)(IDirect3DDevice9*, const RECT*, const RECT*, HWND, const RGNDATA*);
Present_t oPresent = nullptr;

typedef HRESULT(APIENTRY* Reset_t)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);
Reset_t oReset = nullptr;

WNDPROC oWndProc = nullptr;
HWND g_hWnd = nullptr;
bool g_bMenuOpen = false;
bool g_bImGuiInitialized = false;

typedef BOOL(WINAPI* SetCursorPos_t)(int X, int Y);
SetCursorPos_t oSetCursorPos = nullptr;

BOOL WINAPI hkSetCursorPos(int X, int Y) {
    if (g_bMenuOpen) {
        return TRUE;
    }
    return oSetCursorPos(X, Y);
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (msg == WM_KEYUP && wParam == VK_INSERT) {
        g_bMenuOpen = !g_bMenuOpen;
        
        DWORD samp_dll = (DWORD)GetModuleHandleA("samp.dll");
        int samp_version = 0;
        if (samp_dll) {
            IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)samp_dll;
            IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(samp_dll + dos->e_lfanew);
            DWORD ep = nt->OptionalHeader.AddressOfEntryPoint;
            if (ep == 0xCC4D0) samp_version = 3;
        }

        if (samp_version == 3 && RefGame()) {
            if (g_bMenuOpen) {
                RefGame()->SetCursorMode(2, FALSE);
            } else {
                RefGame()->SetCursorMode(0, TRUE);
            }
        }
    }

    if (g_bMenuOpen) {
        if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
            return true;
        if ((msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST) || (msg >= WM_KEYFIRST && msg <= WM_KEYLAST))
            return true;
    }

    return CallWindowProc(oWndProc, hWnd, msg, wParam, lParam);
}

bool GetD3D9Device(void** pTable, size_t Size) {
    if (!pTable) return false;
    IDirect3D9* pD3D = Direct3DCreate9(D3D_SDK_VERSION);
    if (!pD3D) return false;
    
    D3DPRESENT_PARAMETERS d3dpp = {};
    d3dpp.Windowed = false;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.hDeviceWindow = GetForegroundWindow();
    
    IDirect3DDevice9* pDummyDevice = nullptr;
    HRESULT hr = pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3dpp.hDeviceWindow,
                                    D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &pDummyDevice);
    if (FAILED(hr)) {
        d3dpp.Windowed = true;
        hr = pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3dpp.hDeviceWindow,
                                D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &pDummyDevice);
    }
    
    if (FAILED(hr)) {
        pD3D->Release();
        return false;
    }
    
    memcpy(pTable, *reinterpret_cast<void***>(pDummyDevice), Size);
    pDummyDevice->Release();
    pD3D->Release();
    return true;
}

HRESULT APIENTRY hkReset(IDirect3DDevice9* pDevice, D3DPRESENT_PARAMETERS* pPresentationParameters) {
    if (g_bImGuiInitialized) {
        ImGui_ImplDX9_InvalidateDeviceObjects();
    }
    
    HRESULT hr = oReset(pDevice, pPresentationParameters);
    
    if (SUCCEEDED(hr) && g_bImGuiInitialized) {
        ImGui_ImplDX9_CreateDeviceObjects();
    }
    
    return hr;
}

bool HotkeyButton(const char* label, int* k) {
    ImGui::PushID(label);
    char buf[128];
    if (*k == 0) snprintf(buf, sizeof(buf), "None");
    else snprintf(buf, sizeof(buf), "[ Key: 0x%X ]", *k); 
    
    static int* active_k = nullptr;
    if (active_k == k) {
        snprintf(buf, sizeof(buf), "[ Press Key ]");
        for (int i = 3; i < 256; i++) {
            if (GetAsyncKeyState(i) & 0x8000) {
                if (i == VK_ESCAPE) *k = 0;
                else *k = i;
                active_k = nullptr;
                break;
            }
        }
    }
    
    bool ret = ImGui::Button(buf, ImVec2(100, 22));
    if (ret) active_k = k;
    ImGui::SameLine();
    ImGui::Text("%s", label);
    ImGui::PopID();
    return ret;
}

static bool g_show_about = false;
static int g_dpi_scale = 0;
static int g_theme_color = 0;
static float g_anim_speed = 1.0f;

void DrawInfoWindow(bool* open, int* scale, int* color, float* speed) {
    static float alpha = 0.f;
    alpha = ImLerp(alpha, *open ? 1.f : 0.f, ImGui::GetIO().DeltaTime * 8.f * *speed);
    if (alpha < 0.1f)
        return;

    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(300, 450));
    ImGui::Begin("Info window", nullptr, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoDecoration);
    {
        ImGui::SetCursorPos(ImVec2(300 - 25, 5));
        ImVec2 p_close = ImGui::GetCursorScreenPos();
        if (ImGui::InvisibleButton("##close", ImVec2(15, 15))) {
            *open = false;
        }
        bool close_hov = ImGui::IsItemHovered();
        ImGui::GetWindowDrawList()->AddText(p_close, 
            close_hov ? IM_COL32(255, 255, 255, (int)(255 * alpha)) : IM_COL32(150, 150, 150, (int)(255 * alpha)), 
            u8"\uf00d");

        ImGui::SetCursorPosY(110);
        ImGui::BeginGroup();
        {
            ImVec4 text_col = ImVec4(1, 1, 1, alpha);
            ImVec4 val_col = ImVec4(0.8f, 0.8f, 0.8f, alpha);

            ImGui::SetWindowFontScale(1.05f);

            ImGui::SetCursorPosX(15); ImGui::TextColored(text_col, "Version:"); ImGui::SameLine(120); ImGui::TextColored(val_col, "3.0");
            ImGui::SetCursorPosX(15); ImGui::TextColored(text_col, "Build date:"); ImGui::SameLine(120); ImGui::TextColored(val_col, "Feb 24 2022");
            ImGui::SetCursorPosX(15); ImGui::TextColored(text_col, "Build type:"); ImGui::SameLine(120); ImGui::TextColored(val_col, "Debug");
            ImGui::SetCursorPosX(15); ImGui::TextColored(text_col, "Registered to:"); ImGui::SameLine(120); ImGui::TextColored(val_col, "Ultrabomj");
            ImGui::SetCursorPosX(15); ImGui::TextColored(text_col, "Subscription till:"); ImGui::SameLine(120); ImGui::TextColored(val_col, "Lifetime");
            
            ImGui::SetCursorPosY(235);
            const char* cr_text = "neverlose.cc � 2020-2022";
            ImGui::SetCursorPosX((300 - ImGui::CalcTextSize(cr_text).x * 1.05f) / 2.f);
            ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, alpha), cr_text);

            ImGui::SetWindowFontScale(1.0f);
        }
        ImGui::EndGroup();

        ImGui::SetCursorPos(ImVec2(15, 290));
        ImGui::BeginGroup();
        {
            ImGuiWindow* window = ImGui::GetCurrentWindow();
            float old_size_x = window->Size.x;
            window->Size.x = 270;

            static bool bred_ebaniy = false;
            ImGui::Checkbox("Auto Save", &bred_ebaniy);
            
            ImGui::SetNextItemWidth(140);
            ImGui::Combo("Menu Scale", scale, "Auto\0" "50%\0" "75%\0" "100%\0" "125%\0" "150%\0" "175%\0" "200%\0");
            
            ImGui::SetNextItemWidth(140);
            static int esp_scale = 0;
            ImGui::Combo("ESP Scale", &esp_scale, "Auto\0" "50%\0" "75%\0" "100%\0" "125%\0" "150%\0" "175%\0" "200%\0");
            
            ImGui::SetNextItemWidth(60);
            ImGui::SliderFloat("Animation Speed", speed, 0.1f, 2.f, "%.1f");
            
            ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, alpha), "Style");
            
            ImGui::SameLine(140);
            
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 20);

            window->Size.x = old_size_x;
        }
        ImGui::EndGroup();
    }
    ImGui::End();
    ImGui::PopStyleVar(2);
}

HRESULT APIENTRY hkPresent(IDirect3DDevice9* pDevice, const RECT* pSourceRect, const RECT* pDestRect, HWND hDestWindowOverride, const RGNDATA* pDirtyRegion) {
    if (!g_bImGuiInitialized) {
        D3DDEVICE_CREATION_PARAMETERS params;
        pDevice->GetCreationParameters(&params);
        g_hWnd = params.hFocusWindow;
        oWndProc = (WNDPROC)SetWindowLongPtr(g_hWnd, GWLP_WNDPROC, (LONG_PTR)WndProc);

        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

        ImGui::StyleColorsDark();

        ImGui_ImplWin32_Init(g_hWnd);
        ImGui_ImplDX9_Init(pDevice);
        
        io.Fonts->AddFontFromMemoryTTF((void*)museo500_binary, sizeof museo500_binary, 14);
        static const ImWchar icon_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
        static ImFontConfig icons_config;
        icons_config.MergeMode = true;
        icons_config.PixelSnapH = true;
        io.Fonts->AddFontFromMemoryTTF((void*)&font_awesome_binary, sizeof font_awesome_binary, 13, &icons_config, icon_ranges);
        io.Fonts->AddFontFromMemoryTTF((void*)museo900_binary, sizeof museo900_binary, 28);
        
        g_bImGuiInitialized = true;
    }

    if (g_bImGuiInitialized) {
        ImGui_ImplDX9_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        
        ImGuiIO& io = ImGui::GetIO();

        if ( !avatar ) {
            D3DXCreateTextureFromFileExA( pDevice, "c:\\Users\\demid\\Desktop\\neverlose-ui-main\\avatar.png", 30, 30, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &avatar );
            D3DXCreateTextureFromFileInMemoryEx( pDevice, icon_watermark, icon_watermark_size, 15, 15, D3DX_DEFAULT, 0,
                D3DFMT_UNKNOWN, D3DPOOL_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &g_watermark_tex );
            D3DXCreateTextureFromFileInMemoryEx( pDevice, icon_keybinds, icon_keybinds_size, 15, 15, D3DX_DEFAULT, 0,
                D3DFMT_UNKNOWN, D3DPOOL_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &g_keybinds_tex );
        }

        blur::device = pDevice;

        if (g_keybinds.entries.empty()) {
            g_keybinds.reg("Speedhack",      &g_speedhack_enabled,      &g_speedhack_key);
            g_keybinds.reg("Car Jump",        &g_car_jump_enabled,       &g_car_jump_key);
        }

        VehicleHacks_Tick();
        g_keybinds.tick();

        g_watermark.render();
        g_keybinds.render();

        static bool always_true = true;
        g_esp.enable_esp  = &always_true;
        g_esp.draw_box    = &bools[2];
        g_esp.draw_health = &bools[3];
        g_esp.draw_name   = &bools[4];
        g_esp.render();

        if (g_bMenuOpen) {
            static int combo = 0;
            vector < const char* > items = { "Option", "Option 1", "Option 2", "Option 3", "Option 4", "Option 5", ICON_FA_AXE_BATTLE " Option 6", "Option 7", "Option 8", "Option 9" };
            static char buf[64];

            static float color[4] = { 1.f, 1.f, 1.f, 1.f };

            PushStyleVar( ImGuiStyleVar_WindowPadding, ImVec2( 0, 0 ) );

            ImGui::Begin( "Hello, world!", NULL, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground ); {

            auto window = GetCurrentWindow( );
            auto draw   = window->DrawList;
            auto pos    = window->Pos;
            auto size   = window->Size;
            auto style  = GetStyle( );

            gui.m_anim = ImLerp( gui.m_anim, 1.f, 0.045f );

            SetWindowSize( ImVec2( 690, 500 ) );

            draw->AddLine( pos + ImVec2( 170, 0 ), pos + ImVec2( 170, size.y ), GetColorU32( ImGuiCol_WindowBg, 0.5f ) );

            draw->AddText( io.Fonts->Fonts[1], io.Fonts->Fonts[1]->FontSize, pos + ImVec2( 170 / 2 - io.Fonts->Fonts[1]->CalcTextSizeA( io.Fonts->Fonts[1]->FontSize, FLT_MAX, 0, "NEVERLOSE" ).x / 2 + 1, 20 ), gui.accent_color.to_im_color( ), "NEVERLOSE" );
            draw->AddText( io.Fonts->Fonts[1], io.Fonts->Fonts[1]->FontSize, pos + ImVec2( 170 / 2 - io.Fonts->Fonts[1]->CalcTextSizeA( io.Fonts->Fonts[1]->FontSize, FLT_MAX, 0, "NEVERLOSE" ).x / 2, 20 ), GetColorU32( ImGuiCol_Text ), "NEVERLOSE" );

            draw->AddLine( pos + ImVec2( 0, size.y - 50 ), pos + ImVec2( 170, size.y - 50 ), GetColorU32( ImGuiCol_WindowBg, 0.5f ) );
            draw->AddImageRounded( avatar, pos + ImVec2( 15, size.y - 40 ), pos + ImVec2( 45, size.y - 10 ), ImVec2( 0, 0 ), ImVec2( 1, 1 ), ImColor( 1.f, 1.f, 1.f, 1.f ), 100 );
            draw->AddText( pos + ImVec2( 50, size.y - 40 ), gui.text.to_im_color( ), "Ultrabomj" );
            draw->AddText( pos + ImVec2( 50, size.y - 25 ), gui.text_disabled.to_im_color( ), "Till:" );
            draw->AddText( pos + ImVec2( 50 + CalcTextSize( "Till: " ).x, size.y - 25 ), gui.accent_color.to_im_color( ), "Lifetime" );

            SetCursorPos( ImVec2( 10, 70 ) );
            BeginChild( "##tabs", ImVec2( 150, size.y - 120 ) );

            gui.group_title( "Aimbot" );
            if ( gui.tab( ICON_FA_MOUSE, "Legitbot", gui.m_tab == 0 ) && gui.m_tab != 0 )
                gui.m_tab = 0, gui.m_anim = 0.f;

            Spacing( ), Spacing( ), Spacing( );

            gui.group_title( "Visuals" );
            if ( gui.tab( ICON_FA_USER, "Players", gui.m_tab == 1 ) && gui.m_tab != 1 )
                gui.m_tab = 1, gui.m_anim = 0.f;

            if ( gui.tab( ICON_FA_PALLET, "World", gui.m_tab == 2 ) && gui.m_tab != 2 )
                gui.m_tab = 2, gui.m_anim = 0.f;
                
            if ( gui.tab( ICON_FA_CAR, "Vehicle", gui.m_tab == 3 ) && gui.m_tab != 3 )
                gui.m_tab = 3, gui.m_anim = 0.f;

            Spacing( ), Spacing( ), Spacing( );

            gui.group_title( "Miscellaneous" );
            if ( gui.tab( ICON_FA_HAMMER, "Misc", gui.m_tab == 4 ) && gui.m_tab != 4 )
                gui.m_tab = 4, gui.m_anim = 0.f;

            if ( gui.tab( ICON_FA_CODE, "Scripts", gui.m_tab == 5 ) && gui.m_tab != 5 )
                gui.m_tab = 5, gui.m_anim = 0.f;

            EndChild( );

            SetCursorPos( ImVec2( 200, 15 ) );
            Button( ICON_FA_SAVE " Save", ImVec2( 100, 30 ) );

            SetCursorPos( ImVec2( size.x - 70, 15 ) );
            
            ImVec2 p_cog = GetCursorScreenPos();
            if (InvisibleButton("##cog", ImVec2(25, 30))) {
                g_show_about = !g_show_about;
            }
            bool cog_hov = IsItemHovered();
            ImGui::PushStyleColor(ImGuiCol_Text, cog_hov ? IM_COL32(255, 255, 255, 255) : IM_COL32(150, 150, 150, 255));
            ImGui::RenderTextClipped(p_cog, p_cog + ImVec2(25, 30), ICON_FA_COG, NULL, NULL, ImVec2(0.5f, 0.5f));
            ImGui::PopStyleColor();

            ImGui::SameLine();
            
            ImVec2 p_search = GetCursorScreenPos();
            if (InvisibleButton("##search", ImVec2(25, 30))) {
            }
            bool search_hov = IsItemHovered();
            ImGui::PushStyleColor(ImGuiCol_Text, search_hov ? IM_COL32(255, 255, 255, 255) : IM_COL32(150, 150, 150, 255));
            ImGui::RenderTextClipped(p_search, p_search + ImVec2(25, 30), ICON_FA_SEARCH, NULL, NULL, ImVec2(0.5f, 0.5f));
            ImGui::PopStyleColor();

            PushStyleVar( ImGuiStyleVar_Alpha, gui.m_anim );
            PushStyleVar( ImGuiStyleVar_ItemSpacing, ImVec2( 8, 8 ) );

            SetCursorPos( ImVec2( 185, 81 - ( 5 * gui.m_anim ) ) );
            BeginChild( "##childs", ImVec2( size.x - 200, size.y - 96 ) );

            switch ( gui.m_tab ) {

            case 0:
                gui.group_box( ICON_FA_FEATHER " Legitbot", ImVec2( GetWindowWidth( ) / 2 - GetStyle( ).ItemSpacing.x / 2, 210 ) ); {
                    Checkbox( "Skoro t'ma otstypit " ICON_FA_DAGGER, &bools[0] );
                    SliderInt( "Slider", &ints[0], 0, 100, "%d%%" );
                    Combo( "Combo", &combo, items.data( ), items.size( ) );
                    InputText( "Input", buf, sizeof buf );
                    ColorEdit4( "Color", color, ALPHA );
                    Button( "Button", ImVec2( GetWindowWidth( ), 25 ) );
                } gui.end_group_box( );
                break;

            case 1:
                gui.group_box("ESP", ImVec2( GetWindowWidth( ) / 2 - GetStyle( ).ItemSpacing.x / 2, GetWindowHeight( ) ) ); {
                    Checkbox( "2D Box", &bools[2] );
                    if (bools[2]) {
                        ColorEdit4("Box Color", g_esp_box_color, NO_ALPHA);
                    }
                    Checkbox( "Health Bar", &bools[3] );
                    if (bools[3]) {
                        ColorEdit4("Health Top", g_esp_health_grad1, NO_ALPHA);
                        ColorEdit4("Health Bottom", g_esp_health_grad2, NO_ALPHA);
                    }
                    Checkbox( "Name player", &bools[4] );
                } gui.end_group_box( );
                break;

            case 2:
                gui.group_box("World", ImVec2( GetWindowWidth( ) / 2 - GetStyle( ).ItemSpacing.x / 2, GetWindowHeight( ) ) ); {
                    static int skybox_combo = 0;
                    static std::vector<std::string> skybox_names;
                    static std::vector<std::string> skybox_dirs;
                    static std::vector<const char*> skyboxes_ptrs;
                    static bool loaded = false;
                    if (!loaded) {
                        WIN32_FIND_DATAA fd;
                        HANDLE hFind = FindFirstFileA("C:\\Users\\demid\\Desktop\\neverlose-ui-main\\*", &fd);
                        if (hFind != INVALID_HANDLE_VALUE) {
                            do {
                                if ((fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && strcmp(fd.cFileName, ".") != 0 && strcmp(fd.cFileName, "..") != 0 && strcmp(fd.cFileName, "sampapi") != 0 && strcmp(fd.cFileName, "examples") != 0 && strcmp(fd.cFileName, "minhook") != 0) {
                                    std::string folderPath = "C:\\Users\\demid\\Desktop\\neverlose-ui-main\\" + std::string(fd.cFileName);
                                    WIN32_FIND_DATAA fdFiles;
                                    HANDLE hFindFiles = FindFirstFileA((folderPath + "\\*.dff").c_str(), &fdFiles);
                                    if (hFindFiles != INVALID_HANDLE_VALUE) {
                                        FindClose(hFindFiles);
                                        skybox_names.push_back(std::string(fd.cFileName));
                                        skybox_dirs.push_back(folderPath);
                                    }
                                }
                            } while(FindNextFileA(hFind, &fd));
                            FindClose(hFind);
                        }

                        if (skybox_names.empty()) skybox_names.push_back("None found");
                        for (const auto& s : skybox_names) skyboxes_ptrs.push_back(s.c_str());
                        loaded = true;
                    }
                    if (Combo("Skybox", &skybox_combo, skyboxes_ptrs.data(), skyboxes_ptrs.size())) {
                        if (!skybox_dirs.empty() && skybox_combo >= 0 && skybox_combo < skybox_dirs.size()) {
                            std::string folder = skybox_dirs[skybox_combo];
                            std::string dffPath, txdPath;
                            WIN32_FIND_DATAA fd;
                            HANDLE hFind = FindFirstFileA((folder + "\\*.dff").c_str(), &fd);
                            if (hFind != INVALID_HANDLE_VALUE) { dffPath = folder + "\\" + fd.cFileName; FindClose(hFind); }
                            hFind = FindFirstFileA((folder + "\\*.txd").c_str(), &fd);
                            if (hFind != INVALID_HANDLE_VALUE) { txdPath = folder + "\\" + fd.cFileName; FindClose(hFind); }
                            if (!dffPath.empty() && !txdPath.empty()) {
                                extern std::string g_RequestedDff;
                                extern std::string g_RequestedTxd;
                                extern bool g_SkyboxLoadRequested;
                                g_RequestedDff = dffPath;
                                g_RequestedTxd = txdPath;
                                g_SkyboxLoadRequested = true;
                            }
                        }
                    }
                    Separator();
                    static bool g_change_time = false;
                    static int g_time_hours = 12;
                    Checkbox("Custom Time", &g_change_time);
                    if (g_change_time) {
                        SliderInt("Hours", &g_time_hours, 0, 23);
                        if (!IsBadWritePtr((void*)0xB70153, 1)) {
                            *(BYTE*)0xB70153 = (BYTE)g_time_hours;
                        }
                    }
                    Separator();
                    static bool g_change_weather = false;
                    static int g_weather_id = 1;
                    Checkbox("Custom Weather", &g_change_weather);
                    if (g_change_weather) {
                        SliderInt("Weather ID", &g_weather_id, 0, 45);
                        if (!IsBadWritePtr((void*)0xC81320, 1)) {
                            *(BYTE*)0xC81320 = (BYTE)g_weather_id;
                            *(BYTE*)0xC8131C = (BYTE)g_weather_id;
                        }
                    }
                } gui.end_group_box();
                break;

            case 3:
                gui.group_box("Vehicle", ImVec2( GetWindowWidth( ) / 2 - GetStyle( ).ItemSpacing.x / 2, GetWindowHeight( ) ) ); {
                    Checkbox( "Speedhack", &g_speedhack_enabled );
                    if (g_speedhack_enabled) {
                        SliderFloat( "Limit km/h", &g_speedhack_kmh, 0.0f, 400.0f, "%.0f" );
                        SliderFloat( "Sharpness",  &g_speedhack_sharpness, 0.01f, 1.0f, "%.2f" );
                        HotkeyButton("Key", &g_speedhack_key);
                        {
                            DWORD pVeh = *(DWORD*)0xBA18FC;
                            if (pVeh && pVeh > 0x1000 && !IsBadReadPtr((void*)(pVeh + 0x44), 8)) {
                                float vx = *(float*)(pVeh + 0x44);
                                float vy = *(float*)(pVeh + 0x48);
                                float curKmh = sqrtf(vx*vx + vy*vy) * 180.f;
                                char spdbuf[48];
                                snprintf(spdbuf, sizeof(spdbuf), "Speed: %.0f km/h", curKmh);
                                TextDisabled("%s", spdbuf);
                            }
                        }
                    }
                    Separator();
                    Checkbox( "Car Godmode", &g_car_godmode_enabled );
                    Separator();
                    Checkbox( "Always Asphalt", &g_always_asphalt_enabled );
                    Separator();
                    Checkbox( "Faction Bypass", &g_faction_bypass_enabled );
                    Separator();
                    Checkbox( "Unoccupied Bypass", &g_unoccupied_bypass_enabled );
                    Separator();
                    Checkbox( "Unlock All Doors", &g_unlock_doors_enabled );
                    Separator();
                    Checkbox( "Nitro Control", &g_nitro_enabled );
                    Separator();
                    Checkbox( "NoBike", &g_nobike_enabled );
                    Separator();
                    Checkbox( "Car Jump", &g_car_jump_enabled );
                    if (g_car_jump_enabled) {
                        SliderFloat( "Force", &g_car_jump_force, 0.1f, 2.0f, "%.2f" );
                        HotkeyButton("Jump Key", &g_car_jump_key);
                    }
                } gui.end_group_box( );
                break;

            case 4:
                gui.group_box("Misc", ImVec2( GetWindowWidth( ) / 2 - GetStyle( ).ItemSpacing.x / 2, GetWindowHeight( ) ) ); {
                    static bool g_infinite_run = false;
                    Checkbox("Infinite Run", &g_infinite_run);
                    if (g_infinite_run) {
                        if (!IsBadWritePtr((void*)0xB7CB06, 1)) {
                            *(BYTE*)0xB7CB06 = 1;
                        }
                    }
                    Separator();
                    static bool g_cj_run = false;
                    Checkbox("CJ Run", &g_cj_run);
                    if (g_cj_run) {
                        DWORD pPed = *(DWORD*)0xB6F5F0;
                        if (pPed && pPed > 0x1000 && !IsBadWritePtr((void*)(pPed + 0x4D4), 4)) {
                            *(DWORD*)(pPed + 0x4D4) = 118;
                        }
                    }
                } gui.end_group_box( );
                break;

            case 5:
                gui.group_box("Scripts", ImVec2( GetWindowWidth( ) / 2 - GetStyle( ).ItemSpacing.x / 2, 210 ) ); {
                } gui.end_group_box( );
                break;
            }

            EndChild( );

            PopStyleVar( 2 );

        } ImGui::End( );

        if (g_show_about) {
            DrawInfoWindow(&g_show_about, &g_dpi_scale, &g_theme_color, &g_anim_speed);
        }

        PopStyleVar( );
        }
        
        ImGui::EndFrame();
        
        pDevice->SetRenderState(D3DRS_ZENABLE, FALSE);
        pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
        pDevice->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        
        ImGui::Render();
        ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
    }
    
    return oPresent(pDevice, pSourceRect, pDestRect, hDestWindowOverride, pDirtyRegion);
}

typedef void(__cdecl* CTimer_Update_t)();
CTimer_Update_t oTimerUpdate = nullptr;

std::string g_RequestedDff;
std::string g_RequestedTxd;
bool g_SkyboxLoadRequested = false;

void __cdecl hkTimerUpdate() {
    if (g_SkyboxLoadRequested) {
        LoadSkybox(g_RequestedDff, g_RequestedTxd);
        g_SkyboxLoadRequested = false;
    }
    UpdateSkybox();
    
    if (oTimerUpdate)
        oTimerUpdate();
}

DWORD WINAPI MainThread(LPVOID lpReserved) {
    bool hooked = false;
    while (!hooked) {
        void* d3d9Device[119];
        if (GetD3D9Device(d3d9Device, sizeof(d3d9Device))) {
            MH_Initialize();
            MH_CreateHook(d3d9Device[17], (LPVOID)hkPresent, (void**)&oPresent);
            MH_CreateHook(d3d9Device[16], (LPVOID)hkReset, (void**)&oReset);
            MH_CreateHook(reinterpret_cast<LPVOID>(static_cast<BOOL(WINAPI*)(int, int)>(&SetCursorPos)), (LPVOID)hkSetCursorPos, (void**)&oSetCursorPos);
            MH_CreateHook((LPVOID)0x561B10, (LPVOID)hkTimerUpdate, (void**)&oTimerUpdate);
            MH_EnableHook(MH_ALL_HOOKS);
            hooked = true;
        }
        Sleep(100);
    }
    return 0;
}

BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved) {
    switch (dwReason) {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hMod);
        CreateThread(nullptr, 0, MainThread, hMod, 0, nullptr);
        break;
    case DLL_PROCESS_DETACH:
        VehicleHacks_Shutdown();
        MH_DisableHook(MH_ALL_HOOKS);
        MH_Uninitialize();
        if (oWndProc && g_hWnd)
            SetWindowLongPtr(g_hWnd, GWLP_WNDPROC, (LONG_PTR)oWndProc);
        break;
    }
    return TRUE;
}
