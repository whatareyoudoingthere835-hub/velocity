#pragma once
#include <string>
#include <vector>
#include <cmath>
#include <windows.h>
#include "imgui.h"
#include "imgui_internal.h"
#include "gui.hpp"
#include "hashes.hpp"

extern bool g_bMenuOpen;

inline std::string VK_to_string(int vk) {
    if (vk == 0) return "None";
    if (vk == VK_LBUTTON)  return "Mouse1";
    if (vk == VK_RBUTTON)  return "Mouse2";
    if (vk == VK_MBUTTON)  return "Mouse3";
    if (vk == VK_XBUTTON1) return "Mouse4";
    if (vk == VK_XBUTTON2) return "Mouse5";
    if (vk == VK_LSHIFT)   return "LShift";
    if (vk == VK_RSHIFT)   return "RShift";
    if (vk == VK_LCONTROL) return "LCtrl";
    if (vk == VK_RCONTROL) return "RCtrl";
    if (vk == VK_LMENU)    return "LAlt";
    if (vk == VK_RMENU)    return "RAlt";
    if (vk == VK_SPACE)    return "Space";
    if (vk == VK_RETURN)   return "Enter";
    if (vk == VK_ESCAPE)   return "Esc";
    if (vk == VK_BACK)     return "Backspace";
    if (vk == VK_TAB)      return "Tab";
    if (vk == VK_CAPITAL)  return "CapsLock";
    if (vk == VK_DELETE)   return "Delete";
    if (vk == VK_INSERT)   return "Insert";
    if (vk == VK_HOME)     return "Home";
    if (vk == VK_END)      return "End";
    if (vk == VK_PRIOR)    return "PgUp";
    if (vk == VK_NEXT)     return "PgDn";
    if (vk == VK_UP)       return "Up";
    if (vk == VK_DOWN)     return "Down";
    if (vk == VK_LEFT)     return "Left";
    if (vk == VK_RIGHT)    return "Right";
    if (vk >= VK_F1 && vk <= VK_F12)
        return std::string("F") + std::to_string(vk - VK_F1 + 1);
    if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9)
        return std::string("Num") + std::to_string(vk - VK_NUMPAD0);
    UINT scan = MapVirtualKeyA(vk, MAPVK_VK_TO_CHAR);
    if (scan > 0 && scan < 128) {
        char ch = (char)scan;
        if (ch >= 'a' && ch <= 'z') ch -= 32;
        char buf[8] = { ch, 0 };
        return std::string(buf);
    }
    char buf[12];
    snprintf(buf, sizeof(buf), "0x%02X", vk);
    return std::string(buf);
}

struct KeybindEntry {
    std::string name;
    int*        key;
    bool*       enabled;
    bool        held  = false;
    float       anim  = 0.f;
};

struct SmoothFloat {
    float value  = 0.f;
    float target = 0.f;
    float speed  = 8.f;

    void update(float dt, float t) {
        target = t;
        value  = value + (target - value) * (1.f - std::exp(-speed * dt));
    }
    float get() const { return value; }
};

class KeybindsComponent {
public:
    std::vector<KeybindEntry> entries;
    ImVec2 pos = { 10.f, 70.f };
    bool   dragging = false;
    ImVec2 drag_offset = { 0.f, 0.f };

    SmoothFloat widthAnim;
    SmoothFloat alphaAnim;

    void reg(const char* name, bool* enabled, int* key) {
        entries.push_back({ name, key, enabled, false, 0.f });
    }

    void tick() {
        for (auto& e : entries) {
            bool active = e.enabled && *e.enabled && e.key && *e.key != 0;
            if (active) {
                e.held = (GetAsyncKeyState(*e.key) & 0x8000) != 0;
            } else {
                e.held = false;
            }
        }
    }

    void render() {
        float dt = ImGui::GetIO().DeltaTime;

        bool anyHeld = false;
        for (auto& e : entries)
            if (e.held) { anyHeld = true; break; }

        alphaAnim.speed = 6.f;
        alphaAnim.update(dt, (anyHeld || g_bMenuOpen) ? 1.f : 0.f);
        if (alphaAnim.get() < 0.01f) return;

        float alpha = alphaAnim.get();

        ImFont*    font  = ImGui::GetIO().Fonts->Fonts[0];
        const float fs   = 16.f;
        const float fsS  = 14.f;
        const float H_HDR = 22.f;
        const float H_ROW = 18.f;
        const float PAD   = 8.f;
        const float GAP   = 3.f;
        const float CORNER= 4.f;

        ImU32 bgCol    = IM_COL32(0, 0, 0,  (int)(170 * alpha));
        ImU32 bgBorder = IM_COL32(255, 255, 255, (int)(14  * alpha));
        ImU32 textCol  = IM_COL32(255, 255, 255, (int)(255 * alpha));
        ImU32 dimCol   = IM_COL32(150, 150, 150, (int)(200 * alpha));
        ImVec4 ac4 = ImGui::ColorConvertU32ToFloat4(gui.accent_color.to_im_color());
        ImU32 accentCol  = ImGui::ColorConvertFloat4ToU32({ ac4.x, ac4.y, ac4.z, alpha });
        ImU32 accentDim  = ImGui::ColorConvertFloat4ToU32({ ac4.x * 0.7f, ac4.y * 0.7f, ac4.z * 0.7f, alpha * 0.5f });

        ImDrawList* dl = ImGui::GetForegroundDrawList();
        float cx = pos.x;
        float cy = pos.y;

        const char* hdrText = "  Keybinds";
        float iconW = 25.f;
        float hdrW  = font->CalcTextSizeA(fsS, FLT_MAX, 0, hdrText).x;
        float maxW  = PAD + iconW + hdrW + PAD + 10.f;

        for (auto& e : entries) {
            if (!e.enabled || !*e.enabled || !e.key || *e.key == 0) continue;
            std::string keyStr = VK_to_string(*e.key);
            float nameW = font->CalcTextSizeA(fsS, FLT_MAX, 0, e.name.c_str()).x;
            float keyW  = font->CalcTextSizeA(fsS, FLT_MAX, 0, keyStr.c_str()).x;
            float rowW  = PAD + nameW + 28.f + keyW + PAD;
            if (rowW > maxW) maxW = rowW;
        }

        if (g_bMenuOpen && !anyHeld) {
            const char* msg = "No active binds";
            float msgW = PAD + font->CalcTextSizeA(fsS, FLT_MAX, 0, msg).x + PAD;
            if (msgW > maxW) maxW = msgW;
        }

        widthAnim.speed = 7.f;
        widthAnim.update(dt, maxW);
        float W = widthAnim.get();

        dl->AddRectFilled({cx, cy}, {cx + W, cy + H_HDR}, bgCol,    CORNER);
        dl->AddRect      ({cx, cy}, {cx + W, cy + H_HDR}, bgBorder, CORNER);

        float tx = cx + PAD;
        float ty = cy + (H_HDR - 25.f) * 0.5f;
        if (g_keybinds_tex) {
            dl->AddImage((ImTextureID)g_keybinds_tex, {tx, ty}, {tx + 25.f, ty + 25.f}, {0,0}, {1,1}, accentCol);
        }
        tx += iconW;
        dl->AddText(font, fsS, {tx, cy + (H_HDR - fsS) * 0.5f}, textCol,   hdrText);

        float total_h = H_HDR;
        cy += H_HDR + GAP;

        for (auto& e : entries) {
            bool showRow = false;
            if (g_bMenuOpen) {
                showRow = e.enabled && *e.enabled && e.key && *e.key != 0;
            } else {
                showRow = e.held;
            }

            float tgt = showRow ? 1.f : 0.f;
            e.anim = e.anim + (tgt - e.anim) * (1.f - std::exp(-9.f * dt));
            if (e.anim < 0.01f) continue;

            std::string keyStr = (e.key && *e.key != 0) ? VK_to_string(*e.key) : "None";
            float ea     = e.anim * alpha;
            float slideY = (1.f - e.anim) * 5.f;
            float rowY   = cy - slideY;

            bool isHeld = e.held;
            ImU32 rowBg  = IM_COL32(0,   0,   0,   (int)(150 * ea));
            ImU32 rowBd  = isHeld
                ? ImGui::ColorConvertFloat4ToU32({ ac4.x * 0.6f, ac4.y * 0.6f, ac4.z * 0.6f, ea * 0.5f })
                : IM_COL32(255, 255, 255, (int)(10 * ea));
            ImU32 rowTxt = IM_COL32(255, 255, 255, (int)(255 * ea));
            ImU32 rowDim = IM_COL32(140, 140, 140, (int)(200 * ea));
            ImU32 rowKey = isHeld
                ? ImGui::ColorConvertFloat4ToU32({ ac4.x, ac4.y, ac4.z, ea })
                : IM_COL32(180, 180, 180, (int)(200 * ea));

            dl->AddRectFilled({cx, rowY}, {cx + W, rowY + H_ROW}, rowBg, CORNER);
            dl->AddRect      ({cx, rowY}, {cx + W, rowY + H_ROW}, rowBd, CORNER);

            float keyW = font->CalcTextSizeA(fsS, FLT_MAX, 0, keyStr.c_str()).x;
            float yt   = rowY + (H_ROW - fsS) * 0.5f;

            dl->AddText(font, fsS, {cx + PAD, yt}, rowTxt, e.name.c_str());

            float sepX = cx + W - PAD - keyW - 12.f;
            dl->AddText(font, fsS, {sepX, yt}, rowDim, "|");
            dl->AddText(font, fsS, {cx + W - PAD - keyW, yt}, rowKey, keyStr.c_str());

            cy += H_ROW * e.anim + GAP;
            total_h += (H_ROW + GAP) * e.anim;
        }

        if (g_bMenuOpen) {
            bool hasAny = false;
            for (auto& e : entries)
                if (e.enabled && *e.enabled && e.key && *e.key != 0) { hasAny = true; break; }
            if (!hasAny) {
                float rowY = cy;
                float ea   = alpha;
                ImU32 rowBg  = IM_COL32(0,   0,   0,   (int)(100 * ea));
                ImU32 rowBd  = IM_COL32(255, 255, 255,  (int)(6   * ea));
                ImU32 rowDim = IM_COL32(100, 100, 100,  (int)(180 * ea));
                const char* msg = "No active binds";
                float msgW = font->CalcTextSizeA(fsS, FLT_MAX, 0, msg).x;
                dl->AddRectFilled({cx, rowY}, {cx + W, rowY + H_ROW}, rowBg, CORNER);
                dl->AddRect      ({cx, rowY}, {cx + W, rowY + H_ROW}, rowBd, CORNER);
                dl->AddText(font, fsS, {cx + (W - msgW) * 0.5f, rowY + (H_ROW - fsS) * 0.5f}, rowDim, msg);
                total_h += H_ROW + GAP;
            }
        }

        ImVec2 mouse = ImGui::GetIO().MousePos;
        bool hovered = (mouse.x >= pos.x && mouse.x <= pos.x + W &&
                        mouse.y >= pos.y && mouse.y <= pos.y + H_HDR);
        if (hovered && ImGui::IsMouseClicked(0)) {
            dragging = true;
            drag_offset = { mouse.x - pos.x, mouse.y - pos.y };
        }
        if (!ImGui::IsMouseDown(0)) dragging = false;
        if (dragging) {
            pos.x = mouse.x - drag_offset.x;
            pos.y = mouse.y - drag_offset.y;
        }
    }
};
