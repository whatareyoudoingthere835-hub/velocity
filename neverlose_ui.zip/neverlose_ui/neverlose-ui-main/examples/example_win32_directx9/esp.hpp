#pragma once
#include "imgui.h"
#include "imgui_internal.h"
#include "sampapi/0.3.7-R3-1/CNetGame.h"
#include "sampapi/0.3.7-R3-1/CPed.h"
#include "sampapi/0.3.7-R3-1/CPlayerPool.h"
#include "sampapi/0.3.7-R3-1/CRemotePlayer.h"
#include "sampapi/common/CVector.h"
#include <windows.h>

using namespace sampapi;
using namespace sampapi::v037r3;

using namespace sampapi::v037r3;

inline float g_esp_box_color[4] = {1.f, 1.f, 1.f, 1.f};
inline float g_esp_health_grad1[4] = {0.f, 1.f, 0.f, 1.f};
inline float g_esp_health_grad2[4] = {1.f, 0.f, 0.f, 1.f};

struct SampVec2 {
  float x, y;
};
static SampVec2 ESP_CalcScreenCoords(float x, float y, float z) {
  const float *m = reinterpret_cast<float *>(0xB6FA2C);
  unsigned long dwLenX = *reinterpret_cast<unsigned long *>(0xC17044);
  unsigned long dwLenY = *reinterpret_cast<unsigned long *>(0xC17048);

  float rw_x = (z * m[8]) + (y * m[4]) + (x * m[0]) + m[12];
  float rw_y = (z * m[9]) + (y * m[5]) + (x * m[1]) + m[13];
  float rw_z = (z * m[10]) + (y * m[6]) + (x * m[2]) + m[14];

  if (rw_z <= 0.01f)
    return {-1.f, -1.f};

  float fRecip = 1.0f / rw_z;
  return {rw_x * fRecip * (float)dwLenX, rw_y * fRecip * (float)dwLenY};
}
static void ESP_DrawOutlinedText(ImDrawList *dl, ImVec2 pos, ImU32 col,const char *text) {
  ImU32 black = IM_COL32(0, 0, 0, 255);
  dl->AddText(ImVec2(pos.x + 1, pos.y + 1), black, text);
  dl->AddText(pos, col, text);
}
static void ESP_DrawHealthBar(ImDrawList *dl, float x, float y, float h,float hp) {
  float barX = x - 6.f;
  float frac = hp / 100.f;
  if (frac < 0.f)
    frac = 0.f;
  if (frac > 1.f)
    frac = 1.f;

  ImU32 bgCol = IM_COL32(0, 0, 0, 180);

  ImU32 colTop = ImGui::ColorConvertFloat4ToU32(*(ImVec4 *)g_esp_health_grad1);
  ImU32 colBot = ImGui::ColorConvertFloat4ToU32(*(ImVec4 *)g_esp_health_grad2);

  float barH = h * frac;

  dl->AddRectFilled(ImVec2(barX - 1.f, y - 1.f),ImVec2(barX + 2.f, y + h + 1.f),bgCol);
  dl->AddRectFilledMultiColor(ImVec2(barX, y + h - barH),ImVec2(barX + 1.f, y + h), colTop, colTop, colBot,colBot);
}
class ESPComponent {
public:
  bool *enable_esp = nullptr;
  bool *draw_box = nullptr;
  bool *draw_health = nullptr;
  bool *draw_name = nullptr;

  void render() {
    if (!enable_esp || !*enable_esp)return;

    ImDrawList *dl = ImGui::GetBackgroundDrawList();

    DWORD samp_dll = (DWORD)GetModuleHandleA("samp.dll");
    int samp_version = 0;
    if (samp_dll) {
      IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)samp_dll;
      IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *)(samp_dll + dos->e_lfanew);
      DWORD ep = nt->OptionalHeader.AddressOfEntryPoint;
      if (ep == 0xCC4D0)
        samp_version = 3;
    }

    if (samp_version == 3 && RefNetGame() && RefNetGame()->GetPlayerPool()) {
      CPlayerPool *pool = RefNetGame()->GetPlayerPool();
      for (int i = 0; i < 1004; i++) {
        if (!pool->IsConnected(i))continue;

        CRemotePlayer *player = pool->GetPlayer((ID)i);
        if (!player || IsBadReadPtr(player, sizeof(CRemotePlayer)))continue;
        if (!player->m_pPed || IsBadReadPtr(player->m_pPed, 4))continue;
        if (player->m_pPed->IsDead())continue;

        void *gameped = player->m_pPed->m_pGamePed;
        if (!gameped || IsBadReadPtr(gameped, 0x544))continue;

        float hp = *(float *)((uintptr_t)gameped + 0x540);
        if (hp <= 0.f || hp > 1000.f)continue;

        CMatrix matrix;
        player->m_pPed->GetMatrix(&matrix);
        DrawBox(dl, matrix.pos.x, matrix.pos.y, matrix.pos.z, hp,pool->GetName(i), i);
      }
      return;
    }

    struct CPool {
      void *m_pObjects;
      BYTE *m_byteMap;
      int m_nSize;
    };
    CPool *pPedPool = *(CPool **)0xB74490;
    if (!pPedPool || !pPedPool->m_pObjects)
      return;

    DWORD localPed = *(DWORD *)0xB6F5F0;
    for (int i = 0; i < pPedPool->m_nSize; i++) {
      if ((pPedPool->m_byteMap[i] & 0x80) == 0) {
        DWORD ped = (DWORD)pPedPool->m_pObjects + i * 0x7C4;
        if (ped == localPed || ped == 0)
          continue;

        float hp = *(float *)(ped + 0x540);
        if (hp <= 0.f || hp > 1000.f)
          continue;

        DWORD pMatrix = *(DWORD *)(ped + 0x14);
        if (!pMatrix)
          continue;

        float x = *(float *)(pMatrix + 0x30);
        float y = *(float *)(pMatrix + 0x34);
        float z = *(float *)(pMatrix + 0x38);

        DrawBox(dl, x, y, z, hp, "Player/NPC", -1);
      }
    }
  }

private:
  void DrawBox(ImDrawList *dl, float px, float py, float pz, float hp,const char *name, int id) {
    SampVec2 footScreen = ESP_CalcScreenCoords(px, py, pz - 1.1f);
    SampVec2 headScreen = ESP_CalcScreenCoords(px, py, pz + 0.9f);

    if (footScreen.x == -1.f || headScreen.x == -1.f)return;

    float h = footScreen.y - headScreen.y;
    if (h < 5.f || h > 1000.f)return;
    float w = h / 2.f;
    float x = footScreen.x - (w / 2.f);
    float y = headScreen.y;

    ImU32 white = ImGui::ColorConvertFloat4ToU32(*(ImVec4 *)g_esp_box_color);
    ImU32 black = IM_COL32(0, 0, 0, 255);

    if (draw_box && *draw_box) {
      dl->AddRect(ImVec2(x - 1, y - 1), ImVec2(x + w + 1, y + h + 1), black);
      dl->AddRect(ImVec2(x + 1, y + 1), ImVec2(x + w - 1, y + h - 1),black);
      dl->AddRect(ImVec2(x, y), ImVec2(x + w, y + h), white);
    }

    if (draw_health && *draw_health) {
      ESP_DrawHealthBar(dl, x, y, h, hp);
    }

    if (draw_name && *draw_name) {
      if (name && name[0]) {
        char buf[64];
        if (id != -1)
          snprintf(buf, sizeof(buf), "%s [%d]", name, id);else
          snprintf(buf, sizeof(buf), "%s", name);

        ImVec2 ts = ImGui::CalcTextSize(buf);
        ImVec2 textPos = ImVec2(x + w / 2.f - ts.x / 2.f, y - ts.y - 2.f);
        ESP_DrawOutlinedText(dl, textPos, white, buf);
      }
    }
  }
};

inline ESPComponent g_esp;
